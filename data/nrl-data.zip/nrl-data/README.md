The details of the datasets in this folder are as follows:

All files are .mat files, you can read them in the following way

```python
import scipy.io as sio
import os

dataset_name = 'wikipedia.mat'
dataset_root = '.'
dataset_path = os.path.join(dataset_root, dataset_name)

dataset = sio.loadmat(dataset_path)

adj_mat = dataset['network']
labels = dataset['group']
```

The labels are stored under the 'group' key and the adjacency matrix is stored under the 'network' key. They are both sparse matrices. The labels are one hot encoded. 
